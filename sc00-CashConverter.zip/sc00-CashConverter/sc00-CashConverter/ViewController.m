//
//  ViewController.m
//  sc00-CashConverter
//
//  Created by user on 9/25/17.
//  Copyright © 2017 user. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtAmount;
@property (weak, nonatomic) IBOutlet UIButton *btnConvert;
@property (weak, nonatomic) IBOutlet UILabel *lblResult;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnConvertPressed:(id)sender {
    // convert the contents of the control (text attribute)
    // to numeric value
    double result;       // to hold the calculation of the conversion
    if ([self.txtAmount.text length] == 0){
        UIAlertController *myController = [UIAlertController alertControllerWithTitle:@"Error" message:@"Enter something silly" preferredStyle:UIAlertControllerStyleAlert];
        
    }
    else {
        result = [self.txtAmount.text doubleValue] * .84;
        
        // display in the result label our conversion
        [self.lblResult setText:[NSString stringWithFormat:@"E$ %f", result]];
    }
    
}

-(IBAction)backgroundTap:(id)sender{
    [self.txtAmount resignFirstResponder];
}


















@end
